﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace API.Controllers
{
    public class GetTextController : ApiController
    {

        // GET: api/GetText
        public async Task<string> GetAsync()
        {
            return await Task.FromResult(new BI.ProgramLogic().GetMiracleText());
        }

    }
}
