﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Configuration;
using System.Threading.Tasks;

namespace Program
{
    class Program
    {
        // New code:
        static HttpClient client = new HttpClient();
        static string path = "api/gettext";
        static string methodToWrite = ConfigurationSettings.AppSettings["whereToWrite"];

        static void Main(string[] args)
        {
            RunAsync().Wait();
        }

        static async Task RunAsync()
        {
            client.BaseAddress = new Uri("http://localhost:2148/");
            client.DefaultRequestHeaders.Accept.Clear();

            try
            {
                string text = await GetTextAsync();
                switch (methodToWrite)
                {
                    case "Console" :
                        new WriteTextToConsole().Set(text);
                        break;
                    default:
                        break;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

            Console.ReadLine();
        }

        static async Task<string> GetTextAsync()
        {
            string result = string.Empty;
            HttpResponseMessage response = await client.GetAsync(path);
            if (response.IsSuccessStatusCode)
            {
                result = await response.Content.ReadAsAsync<string>();
            }
            return result;
        }


    }
}
