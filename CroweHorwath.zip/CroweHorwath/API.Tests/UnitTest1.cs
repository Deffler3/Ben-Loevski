﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net.Http;
using System.Threading.Tasks;
using API.Controllers;

namespace API.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public async Task GetTextAsync_ShouldReturnText()
        {
            var controller = new GetTextController();

            string result = await controller.GetAsync();
            Assert.AreEqual("Hello World", result);
        }

    }
}
